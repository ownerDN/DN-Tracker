import 'package:flutter/material.dart';

void main() => runApp(const DNTrackerApp());

class Habit {
  String name;
  List<bool> days;
  Habit(this.name, int count) : days = List.filled(count, false);
}

class DNTrackerApp extends StatelessWidget {
  const DNTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DN Tracker',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF080809),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE50914),
          brightness: Brightness.dark,
        ),
      ),
      home: const TrackerHome(),
    );
  }
}

class TrackerHome extends StatefulWidget {
  const TrackerHome({super.key});

  @override
  State<TrackerHome> createState() => _TrackerHomeState();
}

class _TrackerHomeState extends State<TrackerHome> {
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  List<Habit> habits = [];
  int dayRating = 0;

  int get dayCount => DateTime(month.year, month.month + 1, 0).day;

  @override
  void initState() {
    super.initState();
    _resetHabits();
  }

  void _resetHabits() {
    habits = [
      Habit('Quran', dayCount),
      Habit('Gym', dayCount),
      Habit('Journaling', dayCount),
      Habit('Reading', dayCount),
      Habit('Study', dayCount),
      Habit('3K Steps', dayCount),
    ];
  }

  double get progress {
    if (habits.isEmpty) return 0;
    final total = habits.length * dayCount;
    final done = habits.fold<int>(
      0,
      (sum, h) => sum + h.days.where((v) => v).length,
    );
    return total == 0 ? 0 : done / total;
  }

  int done(Habit h) => h.days.where((v) => v).length;

  String monthTitle() {
    const m = [
      'January','February','March','April','May','June',
      'July','August','September','October','November','December'
    ];
    return '${m[month.month - 1]} ${month.year}';
  }

  void changeMonth(int delta) {
    setState(() {
      month = DateTime(month.year, month.month + delta);
      _resetHabits();
      dayRating = 0;
    });
  }

  void addHabit() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('New Habit'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'مثال: صلاة / مذاكرة / قراءة',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final name = controller.text.trim();
              if (name.isNotEmpty) {
                setState(() => habits.add(Habit(name, dayCount)));
              }
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  void deleteHabit(int index) {
    setState(() => habits.removeAt(index));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'DN TRACKER',
          style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2),
        ),
        actions: [
          IconButton(
            tooltip: 'Add habit',
            onPressed: addHabit,
            icon: const Icon(Icons.add_circle_outline),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _header(),
          const SizedBox(height: 12),
          _summary(),
          const SizedBox(height: 12),
          _habitGrid(),
          const SizedBox(height: 12),
          _topHabits(),
          const SizedBox(height: 12),
          _rating(),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(
          colors: [Color(0xFF16161A), Color(0xFF24090C)],
        ),
        border: Border.all(color: const Color(0xFF33333A)),
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: const Color(0xFFE50914),
                width: 2,
              ),
            ),
            child: const Text(
              'DN',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  monthTitle(),
                  style: const TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () => changeMonth(-1),
                      icon: const Icon(Icons.chevron_left),
                    ),
                    const Text('Month'),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () => changeMonth(1),
                      icon: const Icon(Icons.chevron_right),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _summary() {
    final percent = (progress * 100).round();
    final checked = habits.fold<int>((s, h) => s + done(h));
    return Row(
      children: [
        Expanded(
          child: _statCard('$percent%', 'TOTAL PROGRESS', progress),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _numberCard('$checked', 'CHECKED'),
        ),
      ],
    );
  }

  Widget _statCard(String value, String label, double p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121216),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF2E2E34)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(label, style: const TextStyle(fontSize: 10, color: Colors.white54)),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(value: p, minHeight: 7),
          ),
        ],
      ),
    );
  }

  Widget _numberCard(String value, String label) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121216),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF2E2E34)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(label, style: const TextStyle(fontSize: 10, color: Colors.white54)),
          const SizedBox(height: 19),
          const Text('Keep going 🔥', style: TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }

  Widget _habitGrid() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF111114),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF2D2D33)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _gridHeader(),
            const Divider(height: 1),
            ...List.generate(habits.length, (index) => _habitRow(index)),
          ],
        ),
      ),
    );
  }

  Widget _gridHeader() {
    return Row(
      children: [
        const SizedBox(
          width: 120,
          child: Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              'HABIT',
              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white54),
            ),
          ),
        ),
        ...List.generate(
          dayCount,
          (i) => SizedBox(
            width: 38,
            child: Center(
              child: Text(
                '${i + 1}',
                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _habitRow(int index) {
    final habit = habits[index];
    return Row(
      children: [
        SizedBox(
          width: 120,
          height: 44,
          child: GestureDetector(
            onLongPress: () => deleteHabit(index),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      habit.name,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        ...List.generate(
          dayCount,
          (day) => SizedBox(
            width: 38,
            height: 44,
            child: Center(
              child: GestureDetector(
                onTap: () {
                  setState(() => habit.days[day] = !habit.days[day]);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 120),
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: habit.days[day]
                        ? const Color(0xFFE50914)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: habit.days[day]
                          ? const Color(0xFFE50914)
                          : Colors.white30,
                    ),
                  ),
                  child: habit.days[day]
                      ? const Icon(Icons.check, size: 17)
                      : null,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _topHabits() {
    final sorted = [...habits]..sort((a, b) => done(b).compareTo(done(a)));
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF111114),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF2D2D33)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'TOP HABITS',
            style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4),
          ),
          const SizedBox(height: 12),
          ...sorted.take(5).toList().asMap().entries.map((entry) {
            final h = entry.value;
            final p = dayCount == 0 ? 0.0 : done(h) / dayCount;
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  SizedBox(width: 28, child: Text('#${entry.key + 1}')),
                  Expanded(child: Text(h.name, overflow: TextOverflow.ellipsis)),
                  SizedBox(
                    width: 90,
                    child: LinearProgressIndicator(value: p),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 38,
                    child: Text('${(p * 100).round()}%'),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _rating() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF111114),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF2D2D33)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'RATE YOUR DAY',
            style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(5, (i) {
              final selected = dayRating == i + 1;
              return IconButton(
                onPressed: () => setState(() => dayRating = i + 1),
                iconSize: 32,
                icon: Icon(
                  selected ? Icons.star : Icons.star_border,
                  color: selected ? const Color(0xFFE50914) : Colors.white38,
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}
