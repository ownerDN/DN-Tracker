# DN Tracker — Cloud APK Build

1. Create a GitHub repository.
2. Upload the contents of this project to the repository (including `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab.
4. Choose **Build DN Tracker APK**.
5. Press **Run workflow**.
6. When the workflow finishes, open the run and download the **DN-Tracker-APK** artifact.
7. Extract the artifact to get `app-release.apk`.

This builds the Flutter project in GitHub's cloud, so AndroidIDE is not needed.
